window.addEventListener("DOMContentLoaded", () => {

    // Flash messages
    const flashes = document.querySelectorAll(".flashes li");
    flashes.forEach(flash => {
        flash.style.opacity = "1";
        flash.style.transform = "translateX(-50%)"; // centraliza horizontalmente
        flash.style.transition = "opacity 0.5s, transform 0.5s";

        // Remove depois de 3 segundos
        setTimeout(() => {
            flash.style.opacity = "0";
            flash.style.transform = "translateX(-50%) translateY(-20px)";
            setTimeout(() => flash.remove(), 500);
        }, 3000);
    });

    // Modal delete (mantido igual)
    document.querySelectorAll('.delete').forEach(btn => {
        btn.addEventListener('click', e => {
            e.preventDefault();

            const modal = document.createElement('div');
            modal.style.position = 'fixed';
            modal.style.top = 0;
            modal.style.left = 0;
            modal.style.width = '100%';
            modal.style.height = '100%';
            modal.style.background = 'rgba(0,0,0,0.6)';
            modal.style.display = 'flex';
            modal.style.alignItems = 'center';
            modal.style.justifyContent = 'center';
            modal.style.zIndex = 9999;
            modal.style.opacity = 0;
            modal.style.transition = 'opacity 0.3s ease-in-out';

            modal.innerHTML = `
                <div style="background:white;padding:25px;border-radius:8px;text-align:center;max-width:400px;box-shadow:0 5px 15px rgba(0,0,0,0.3);transform: translateY(-20px);transition: transform 0.3s ease-in-out;">
                    <p style="margin-bottom:20px;font-weight:600;font-size:16px;">Deseja realmente deletar este doador?</p>
                    <button id="confirmDel" style="margin-right:10px;padding:8px 20px;background:#e74c3c;color:white;border:none;border-radius:4px;cursor:pointer;font-weight:600;">Sim</button>
                    <button id="cancelDel" style="padding:8px 20px;background:#95a5a6;color:white;border:none;border-radius:4px;cursor:pointer;font-weight:600;">Não</button>
                </div>
            `;

            document.body.appendChild(modal);

            setTimeout(() => {
                modal.style.opacity = 1;
                modal.firstElementChild.style.transform = 'translateY(0)';
            }, 10);

            modal.querySelector('#confirmDel').addEventListener('click', () => {
                window.location.href = btn.href;
            });

            modal.querySelector('#cancelDel').addEventListener('click', () => {
                modal.style.opacity = 0;
                modal.firstElementChild.style.transform = 'translateY(-20px)';
                setTimeout(() => modal.remove(), 300);
            });
        });
    });

});

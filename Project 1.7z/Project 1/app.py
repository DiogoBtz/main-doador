from flask import Flask, render_template, redirect, url_for, request, flash, session
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

# ===========================
# Configuração do Flask
# ===========================
app = Flask(__name__)
app.config['SECRET_KEY'] = 'supersegredo123'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
db = SQLAlchemy(app)

# ===========================
# Modelos
# ===========================
class Doador(db.Model):
    cpf = db.Column(db.String(14), primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    ano_nascimento = db.Column(db.Integer, nullable=False)
    idade = db.Column(db.Integer, nullable=False)
    altura = db.Column(db.Float, nullable=False)
    peso = db.Column(db.Float, nullable=False)

class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    senha = db.Column(db.String(200), nullable=False)  # hash
    role = db.Column(db.String(20), nullable=False, default="recepcionista")  # admin ou recepcionista

# ===========================
# Configurações de validação
# ===========================
IDADE_MINIMA = 18
IDADE_MAXIMA = 69
PESO_MINIMO = 50
PESO_MAXIMO = 140

def calcular_idade(ano_nascimento):
    return datetime.now().year - ano_nascimento

def validar_idade(idade):
    return IDADE_MINIMA <= idade <= IDADE_MAXIMA

def validar_peso(peso):
    return PESO_MINIMO <= peso <= PESO_MAXIMO

# ===========================
# Rotas de login e logout
# ===========================
@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        senha = request.form['senha']

        usuario = Usuario.query.filter_by(username=username).first()

        if usuario and check_password_hash(usuario.senha, senha):
            session['usuario_id'] = usuario.id
            session['role'] = usuario.role
            flash(f"✔️ Login realizado como {usuario.role}!", "success")
            return redirect(url_for('doadores'))
        else:
            flash("⚠️ Usuário ou senha incorretos!", "error")

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash("Você foi deslogado!", "info")
    return redirect(url_for('login'))

# ===========================
# Rota unificada de Doadores
# ===========================
@app.route('/doadores')
def doadores():
    if 'usuario_id' not in session:
        return redirect(url_for('login'))

    doadores = Doador.query.all()
    role = session.get('role')
    return render_template('doadores.html', doadores=doadores, role=role)

# ===========================
# Rotas de CRUD de Doador
# ===========================
@app.route('/cadastrar', methods=['GET', 'POST'])
def cadastrar():
    if 'usuario_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        cpf = request.form['cpf']
        nome = request.form['nome']
        ano_nasc = int(request.form['ano_nascimento'])
        altura = float(request.form['altura'])
        peso = float(request.form['peso'])
        idade = calcular_idade(ano_nasc)

        if Doador.query.get(cpf):
            flash(f"⚠️ CPF {cpf} já cadastrado.", "error")
            return redirect(url_for('cadastrar'))

        if not validar_idade(idade):
            flash(f"⚠️ Idade ({idade}) fora do permitido!", "error")
            return redirect(url_for('cadastrar'))

        if not validar_peso(peso):
            flash(f"⚠️ Peso ({peso} kg) fora do permitido!", "error")
            return redirect(url_for('cadastrar'))

        novo = Doador(
            cpf=cpf,
            nome=nome,
            ano_nascimento=ano_nasc,
            idade=idade,
            altura=altura,
            peso=peso
        )
        db.session.add(novo)
        db.session.commit()
        flash("✔️ Doador cadastrado com sucesso!", "success")
        return redirect(url_for('doadores'))

    return render_template('cadastrar.html')

@app.route('/editar/<cpf>', methods=['GET', 'POST'])
def editar(cpf):
    if 'usuario_id' not in session:
        return redirect(url_for('login'))

    doador = Doador.query.get_or_404(cpf)

    if request.method == 'POST':
        novo_cpf = request.form['cpf']

        if novo_cpf != doador.cpf and Doador.query.get(novo_cpf):
            flash(f"⚠️ CPF {novo_cpf} já cadastrado.", "error")
            return redirect(url_for('editar', cpf=cpf))

        doador.nome = request.form['nome']
        doador.ano_nascimento = int(request.form['ano_nascimento'])
        doador.altura = float(request.form['altura'])
        doador.peso = float(request.form['peso'])
        doador.idade = calcular_idade(doador.ano_nascimento)

        if not validar_idade(doador.idade):
            flash(f"⚠️ Idade ({doador.idade}) fora do permitido!", "error")
            return redirect(url_for('editar', cpf=cpf))
        if not validar_peso(doador.peso):
            flash(f"⚠️ Peso ({doador.peso} kg) fora do permitido!", "error")
            return redirect(url_for('editar', cpf=cpf))

        doador.cpf = novo_cpf
        db.session.commit()
        flash("✔️ Doador atualizado com sucesso!", "success")
        return redirect(url_for('doadores'))

    return render_template('editar.html', doador=doador)

@app.route('/deletar/<cpf>')
def deletar(cpf):
    if 'usuario_id' not in session:
        return redirect(url_for('login'))
    if session.get('role') != 'admin':
        flash("⚠️ Apenas admin pode deletar!", "error")
        return redirect(url_for('doadores'))

    doador = Doador.query.get(cpf)
    if doador:
        db.session.delete(doador)
        db.session.commit()
        flash("✔️ Doador deletado com sucesso!", "success")
    else:
        flash("⚠️ Doador não encontrado!", "error")
    return redirect(url_for('doadores'))



# ===========================
# Inicialização do banco e app
# ===========================
if __name__ == '__main__':
    with app.app_context():
        db.create_all()

        # Usuário admin inicial
        if not Usuario.query.filter_by(username='admin').first():
            admin = Usuario(
                username="admin",
                senha=generate_password_hash("admin123"),
                role="admin"
            )
            db.session.add(admin)
            db.session.commit()

        # Usuário recepcionista inicial
        if not Usuario.query.filter_by(username='recep').first():
            recep = Usuario(
                username="recep",
                senha=generate_password_hash("senha123"),
                role="recepcionista"
            )
            db.session.add(recep)
            db.session.commit()

    app.run(debug=True)
